
let EDITMODE = true;
let QUADCANVAS = false;
let disableDrawInterface = false;
let cargoArchivo = true;
let WEBGL_ON = false; //Algunas funcionan con esto otras no. //Si cambia esto cambia e
var dropzone;
document.addEventListener("keypress", documentOnKeyPressed, false);
var RM;
var img;
var interface;
var font;
let shtest;
let pgtest;
var p5jsdraw; 

let click_duration = 5000;
let click_lasttime = 0;
let first_click = false;
let gmixer;

let prevNote;
let init = false;
let lerpmouse = 0.0;

window.onload = function() {
	init = true;
};

function preload() {
	//if(init){return};
    RM = new RenderManager();
	//p5jsdraw1 = new HellwareManager();
	//p5jsdraw1 = new JuninManager();
	//console.log("D e e e e s");
	//RM.addP5draw(p5jsdraw1, 0);
	p5jsdraw1 = new Demop5();
	//RM.addShader("shaders/generative/videosinte.frag",0,"videosinte")
	RM.addP5draw(p5jsdraw1, 0);
	RM.addShader("shaders/imageprocessing/rotatecolor.frag",1,"rotatecolor")
	font = loadFont('./font/Windows Regular.ttf');
	document.getElementById("loading").style.visibility = "hidden";
}

function setup() {
	noiseSeed(genR(1, 100));
	//setFxhashValues_megaspace();
	//setFxhashValues_feedbackpointer();
	document.addEventListener('contextmenu', event => event.preventDefault());
	if (QUADCANVAS) {
		createCanvas(windowHeight, windowHeight, WEBGL)
	} else {
		const cnv = createCanvas(windowWidth, windowHeight, WEBGL) 
		cnv.elt.addEventListener("contextmenu", (e) => e.preventDefault())
	}
	//createCanvas(windowWidth, windowHeght, WEBGL) 
	interface = new Interface(RM);
	/*if (p5jsdraw1) {
		p5jsdraw1.setup();
	}*/
	//p5jsdraw1.setImagePositions();
	frameRate(60)
	pixelDensity(1);
	//Esto es para que no tire error en FXHASH
	if (!disableDrawInterface) {
		textFont(font);
	}
	textFont(font);
	dropzone = select('#defaultCanvas0');
	dropzone.dragOver(highlight);
	dropzone.dragLeave(unhighlight);
	dropzone.drop(processFile, unhighlight);
	textureMode(NORMAL);
	//interface.drawActive = !interface.drawActive;
	interface.drawActive = false;
}
function mousePressed() {
	first_click = true;
}
function mouseWheel(event) {
	
}
function documentOnKeyPressed(event) {
	var keyCode = event.keyCode;
	let chrCode = keyCode - 48 * Math.floor(keyCode / 48);
	let chr = String.fromCharCode(keyCode);
	updateInterfazTeclas(chr);
}
function windowResized() {
	if (QUADCANVAS) {
		resizeCanvas(windowHeight, windowHeight);
	} else {
		resizeCanvas(windowWidth, windowHeight);
	}
	RM.resize();
}

function draw() {

	background(0);
	updateNONglobalUniforms();
	translate(-width / 2, -height / 2, 0); //moves our drawing origin to the top left corner
	
	RM.draw();
	RM.update();
	
	interface.update();
	if (!disableDrawInterface) {
		interface.draw();
		fill(255);
	}

	fill(255, 255);
	for (let i = 0; i < touches.length; i++) {
		fill(255, 0, 0);
		ellipse(touches[i].x, touches[i].y, 10, 10);
	}
	

}

